import { index, pgTable, text, timestamp, uuid } from "drizzle-orm/pg-core";
import { gamePlatformEnum, gameStatusEnum } from "./enums";

export const gamesTable = pgTable(
  "games",
  {
    id: uuid("id").primaryKey().defaultRandom(),
    title: text("title").notNull(),
    coverUrl: text("cover_url"),
    platform: gamePlatformEnum("platform").notNull(),
    status: gameStatusEnum("status").notNull().default("active"),
    createdAt: timestamp("created_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    updatedAt: timestamp("updated_at", { withTimezone: true })
      .notNull()
      .defaultNow(),
    deletedAt: timestamp("deleted_at", { withTimezone: true }),
  },
  (t) => [
    index("games_status_idx").on(t.status),
    index("games_deleted_at_idx").on(t.deletedAt),
  ],
);

export type Game = typeof gamesTable.$inferSelect;
export type InsertGame = typeof gamesTable.$inferInsert;
