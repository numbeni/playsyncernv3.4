# Current Phase

## PS-01 — Backend Foundation and Migration Discipline

Current baseline:

`playsyncernv3.1-main.zip`

Current goal:

- remove unsafe automatic schema push
- establish versioned Drizzle migrations
- add process health and database readiness endpoints
- add central API error handling
- validate UUID route parameters
- add controlled request-size and malformed-JSON handling
- add cryptography and lookup-hash utilities with tests
- align OpenAPI/codegen only for foundation endpoints

Out of scope:

- Games business changes
- Accounts business changes
- Capacity template changes
- Orders redesign
- Store Mapping
- Assignment
- Connector
- Authentication
- Staff
- RBAC
- Dashboard
- destructive database changes

Do not change business schemas during this phase unless the active implementation prompt explicitly authorizes a minimal foundation-only change.
