import { Router, type IRouter, type Request, type Response } from "express";
import { db, gamesTable, accountsTable } from "@workspace/db";
import { eq, isNull, and, desc, count } from "drizzle-orm";
import { z } from "zod";
import { logger } from "../lib/logger";
import { p } from "../lib/req-param";
import { requireUuidParam } from "../lib/validate-uuid";

const router: IRouter = Router();

// Malformed UUID route params fail fast with HTTP 400 instead of reaching the DB.
router.param("id", requireUuidParam("id"));

// ── Validation ──────────────────────────────────────────────────────────────

const CreateGameBody = z.object({
  title: z.string().min(1).max(120),
  coverUrl: z.string().url().optional(),
  platform: z.enum(["PS5_ONLY", "PS4_AND_PS5", "PS4_ONLY"]),
  status: z.enum(["active", "inactive"]).default("active"),
});

const UpdateGameBody = z.object({
  title: z.string().min(1).max(120).optional(),
  coverUrl: z.string().url().nullable().optional(),
  platform: z.enum(["PS5_ONLY", "PS4_AND_PS5", "PS4_ONLY"]).optional(),
  status: z.enum(["active", "inactive"]).optional(),
});

// ── Routes ───────────────────────────────────────────────────────────────────

/** GET /games — list all non-deleted games with account count */
router.get("/games", async (_req: Request, res: Response) => {
  try {
    const rows = await db
      .select({
        id: gamesTable.id,
        title: gamesTable.title,
        coverUrl: gamesTable.coverUrl,
        platform: gamesTable.platform,
        status: gamesTable.status,
        createdAt: gamesTable.createdAt,
        updatedAt: gamesTable.updatedAt,
        accountCount: count(accountsTable.id),
      })
      .from(gamesTable)
      .leftJoin(
        accountsTable,
        and(
          eq(accountsTable.gameId, gamesTable.id),
          isNull(accountsTable.deletedAt),
        ),
      )
      .where(isNull(gamesTable.deletedAt))
      .groupBy(gamesTable.id)
      .orderBy(desc(gamesTable.createdAt));

    res.json({ games: rows });
  } catch (err) {
    logger.error(err, "GET /games failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

/** GET /games/:id — single game */
router.get("/games/:id", async (req: Request, res: Response) => {
  try {
    const [game] = await db
      .select()
      .from(gamesTable)
      .where(eq(gamesTable.id, p(req.params["id"])))
      .limit(1);

    if (!game || game.deletedAt) {
      res.status(404).json({ error: "Game not found" });
      return;
    }
    res.json({ game });
  } catch (err) {
    logger.error(err, "GET /games/:id failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

/** POST /games — create game */
router.post("/games", async (req: Request, res: Response) => {
  const parsed = CreateGameBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Validation failed", issues: parsed.error.issues });
    return;
  }
  try {
    const [game] = await db
      .insert(gamesTable)
      .values(parsed.data)
      .returning();
    res.status(201).json({ game });
  } catch (err) {
    logger.error(err, "POST /games failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

/** PATCH /games/:id — update game */
router.patch("/games/:id", async (req: Request, res: Response) => {
  const parsed = UpdateGameBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Validation failed", issues: parsed.error.issues });
    return;
  }
  try {
    const [game] = await db
      .update(gamesTable)
      .set({ ...parsed.data, updatedAt: new Date() })
      .where(eq(gamesTable.id, p(req.params["id"])))
      .returning();

    if (!game) {
      res.status(404).json({ error: "Game not found" });
      return;
    }
    res.json({ game });
  } catch (err) {
    logger.error(err, "PATCH /games/:id failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

/** DELETE /games/:id — soft delete */
router.delete("/games/:id", async (req: Request, res: Response) => {
  try {
    const [game] = await db
      .update(gamesTable)
      .set({ deletedAt: new Date(), updatedAt: new Date() })
      .where(eq(gamesTable.id, p(req.params["id"])))
      .returning();

    if (!game) {
      res.status(404).json({ error: "Game not found" });
      return;
    }
    res.json({ ok: true });
  } catch (err) {
    logger.error(err, "DELETE /games/:id failed");
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
