---
name: drizzle-kit config and node --test quirks
description: Two environment gotchas hit while adding versioned Drizzle migrations and native node:test unit tests in this pnpm/TS monorepo.
---

- `drizzle-kit check` fails with an ENOENT on a mangled path (`.//abs/path/...`) if `out` in
  `drizzle.config.ts` is an absolute path (e.g. via `path.join(__dirname, ...)`). `generate`
  and `migrate` tolerate the absolute path fine; only `check` breaks. Fix: set `out` to a
  plain relative string (e.g. `"./migrations"`) instead of an absolute path.
  **Why:** discovered when verifying the PS-01 migration workflow on a disposable local
  Postgres — `db:check` errored until `out` was made relative.

- Node's built-in `--test` runner (used to avoid adding vitest/jest as a dependency) requires
  relative imports to include the literal `.ts` extension (e.g. `from "./crypto.ts"`), because
  Node's ESM resolver does no extension inference even with type-stripping enabled. But `tsc`
  rejects `.ts`-suffixed imports unless the tsconfig has `allowImportingTsExtensions: true`,
  which itself requires `noEmit: true` in that same tsconfig (a CLI `--noEmit` flag is not
  enough). **How to apply:** when adding native `node --test` unit tests to a TS package in
  this repo, import test subjects with the `.ts` extension and set both `noEmit` and
  `allowImportingTsExtensions` in that package's own tsconfig.json.

- Backgrounding a local Postgres via `pg_ctl ... start` inside one ShellExec call does not
  survive into the next ShellExec call — the sandbox appears to kill the process group when
  the shell exits, so the server "disappears" between calls even though `pg_ctl` detaches
  normally. **How to apply:** when spinning up a disposable local Postgres for migration
  verification, do the initdb + start + test-queries + stop all inside a single shell command.
