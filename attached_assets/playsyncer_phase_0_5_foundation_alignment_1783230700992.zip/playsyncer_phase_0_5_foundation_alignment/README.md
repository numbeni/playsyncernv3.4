# PlaySyncer — پنل مدیریت

پنل مدیریت مدرن و کاملاً RTL برای مدیریت بازی‌ها، اکانت‌های PlayStation، اسلات‌ها و سفارشات مشتریان.

## استک

- React 19 + Vite 7 + TypeScript
- Tailwind CSS v4
- react-router-dom
- lucide-react
- @fontsource-variable/vazirmatn

## اجرا در محیط لوکال

```bash
# نصب وابستگی‌ها (پیشنهاد: bun یا npm)
bun install
# یا
npm install

# اجرای دیو سرور
bun dev
# یا
npm run dev
```

سپس مرورگر را روی `http://localhost:5173` باز کنید.

## بیلد پروداکشن

```bash
bun run build
bun run preview
```

## ویژگی‌ها

- 🎮 تم گیمینگ نئون (سایان × مجنتا) با پس‌زمینه گرید تاریک
- 🌙 حالت تاریک (پیش‌فرض) + روشن — قابل تغییر از سایدبار یا صفحهٔ تنظیمات
- 📱 کاملاً واکنش‌گرا (موبایل، تبلت، دسکتاپ)
- 🔎 جستجوی هوشمند بازی/اکانت/مشتری
- 🎯 مدیریت اسلات‌های Z2 PS5 #1/#2، Z2 PS4، Z3
- 🇮🇷 RTL و فارسی

## ساختار

```
src/
  components/   # AppSidebar, GameCard, AccountCard, SmartSearch, ComingSoon, ThemeToggle
  pages/        # GamesPage, GameDetailPage, Orders/Issues/Staff/Settings, NotFound
  hooks/        # useTheme
  lib/          # mock-data.ts, utils.ts
  styles.css    # توکن‌های تم و تنظیمات Tailwind v4
```
