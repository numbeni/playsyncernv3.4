import type { Account } from "@/domain/accounts/types";
import type { Game, Platform } from "@/domain/games/types";
import type { AccountSlot } from "@/domain/slots/types";

const slotsForPlatform = (platform: Platform, seed: number): AccountSlot[] => {
  const base: AccountSlot[] = [
    {
      id: `s-${seed}-z2ps5-1`,
      type: "Z2_PS5_1",
      label: "Z2 PS5 #1",
      customers: [
        {
          id: `c-${seed}-1`,
          maskedIdentifier: "0912***4521",
          orderNumber: "ORD-10248",
          assignedAt: "1403/09/12",
        },
      ],
    },
    {
      id: `s-${seed}-z2ps5-2`,
      type: "Z2_PS5_2",
      label: "Z2 PS5 #2",
      customers: [
        {
          id: `c-${seed}-2`,
          maskedIdentifier: "0935***9812",
          orderNumber: "ORD-10259",
          assignedAt: "1403/09/15",
        },
        {
          id: `c-${seed}-3`,
          maskedIdentifier: "0901***1122",
          orderNumber: "ORD-10263",
          assignedAt: "1403/09/18",
        },
      ],
    },
    {
      id: `s-${seed}-z3ps5`,
      type: "Z3_PS5",
      label: "Z3 PS5",
      customers: [],
    },
  ];

  if (platform === "PS4_AND_PS5") {
    base.splice(2, 0, {
      id: `s-${seed}-z2ps4-1`,
      type: "Z2_PS4_1",
      label: "Z2 PS4 #1",
      customers: [
        {
          id: `c-${seed}-4`,
          maskedIdentifier: "0919***5544",
          orderNumber: "ORD-10201",
          assignedAt: "1403/09/02",
        },
      ],
    });
  }

  return base;
};

const makeAccounts = (gameId: string, platform: Platform, count: number): Account[] =>
  Array.from({ length: count }).map((_, index) => {
    const accountIndex = index + 1;
    const disabled = accountIndex % 7 === 0;

    return {
      id: `${gameId}-acc-${accountIndex}`,
      number: `#${gameId.toUpperCase()}-${String(accountIndex).padStart(3, "0")}`,
      email: `${gameId}.account${accountIndex}@playsyncer.io`,
      password: `Ps@${gameId}${accountIndex}${accountIndex}${accountIndex}!`,
      onlineId: `PSN_${gameId}_${accountIndex}`,
      backupCodes: ["a4f9-22", "b7c1-88", "e6d3-14", "9k22-ll"],
      status: disabled ? "disabled" : "active",
      slots: slotsForPlatform(platform, accountIndex),
    };
  });

export const games: Game[] = [
  {
    id: "gta6",
    title: "GTA VI",
    cover: "https://images.unsplash.com/photo-1552820728-8b83bb6b773f?w=800&auto=format&fit=crop",
    platform: "PS5_ONLY",
    accounts: makeAccounts("gta6", "PS5_ONLY", 6),
  },
  {
    id: "ea-fc25",
    title: "EA Sports FC 25",
    cover: "https://images.unsplash.com/photo-1579952363873-27f3bade9f55?w=800&auto=format&fit=crop",
    platform: "PS4_AND_PS5",
    accounts: makeAccounts("ea-fc25", "PS4_AND_PS5", 8),
  },
  {
    id: "cod-bo6",
    title: "Call of Duty: Black Ops 6",
    cover: "https://images.unsplash.com/photo-1552820728-8b83bb6b773f?w=800&auto=format&fit=crop&sat=-50",
    platform: "PS4_AND_PS5",
    accounts: makeAccounts("cod-bo6", "PS4_AND_PS5", 5),
  },
  {
    id: "spiderman2",
    title: "Marvel's Spider-Man 2",
    cover: "https://images.unsplash.com/photo-1635805737707-575885ab0820?w=800&auto=format&fit=crop",
    platform: "PS5_ONLY",
    accounts: makeAccounts("spiderman2", "PS5_ONLY", 4),
  },
  {
    id: "gow-ragnarok",
    title: "God of War: Ragnarök",
    cover: "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=800&auto=format&fit=crop",
    platform: "PS4_AND_PS5",
    accounts: makeAccounts("gow-ragnarok", "PS4_AND_PS5", 7),
  },
  {
    id: "hogwarts",
    title: "Hogwarts Legacy",
    cover: "https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=800&auto=format&fit=crop",
    platform: "PS4_AND_PS5",
    accounts: makeAccounts("hogwarts", "PS4_AND_PS5", 3),
  },
];
