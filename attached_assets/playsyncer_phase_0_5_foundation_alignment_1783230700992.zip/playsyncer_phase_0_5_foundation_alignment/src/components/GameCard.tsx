import { Link } from "react-router-dom";
import { ArrowLeft, Gamepad2 } from "lucide-react";
import type { Game } from "@/domain/games/types";
import { platformLabel } from "@/domain/games/platform";
import { getGameStats } from "@/domain/games/stats";
import { cn } from "@/lib/utils";

export function GameCard({ game }: { game: Game }) {
  const stats = getGameStats(game);
  const isPs5Only = game.platform === "PS5_ONLY";

  return (
    <div className="group relative flex flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-soft transition-all hover:shadow-elevated hover:-translate-y-0.5 hover:border-primary/50">
      <div className="relative aspect-[16/10] overflow-hidden bg-muted">
        <img
          src={game.cover}
          alt={game.title}
          loading="lazy"
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/30 to-transparent" />
        <div className="absolute top-3 right-3">
          <span
            className={cn(
              "inline-flex items-center gap-1 rounded-full px-2.5 py-1 text-[11px] font-semibold backdrop-blur border",
              isPs5Only
                ? "bg-primary/20 text-primary border-primary/40"
                : "bg-card/80 text-foreground border-border",
            )}
          >
            <Gamepad2 className="h-3 w-3" />
            {platformLabel(game.platform)}
          </span>
        </div>
        <div className="absolute inset-x-4 bottom-3">
          <h3 className="text-lg font-bold text-white drop-shadow-lg">{game.title}</h3>
        </div>
      </div>

      <div className="grid grid-cols-4 gap-2 p-4 border-b border-border">
        <Stat label="اکانت‌ها" value={stats.totalAccounts} />
        <Stat label="فعال" value={stats.activeAccounts} tone="success" />
        <Stat label="اسلات‌ها" value={stats.totalSlots} />
        <Stat label="تخصیص" value={stats.totalAssignments} tone="primary" />
      </div>

      <div className="p-4">
        <Link
          to={`/games/${game.id}`}
          className="group/btn flex w-full items-center justify-between rounded-xl gradient-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground shadow-soft transition-all hover:shadow-glow"
        >
          <span>ورود به مدیریت اکانت‌ها</span>
          <ArrowLeft className="h-4 w-4 transition-transform group-hover/btn:-translate-x-1" />
        </Link>
      </div>
    </div>
  );
}

function Stat({
  label,
  value,
  tone,
}: {
  label: string;
  value: number;
  tone?: "primary" | "success";
}) {
  return (
    <div className="min-w-0 text-center">
      <div
        className={cn(
          "text-lg font-bold tabular-nums",
          tone === "primary" && "text-primary",
          tone === "success" && "text-success",
        )}
      >
        {value.toLocaleString("fa-IR")}
      </div>
      <div className="mt-0.5 truncate text-[10px] text-muted-foreground">{label}</div>
    </div>
  );
}
