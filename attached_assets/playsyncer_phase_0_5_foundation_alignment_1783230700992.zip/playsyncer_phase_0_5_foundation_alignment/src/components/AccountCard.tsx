import { useState } from "react";
import {
  ChevronDown,
  Copy,
  Eye,
  EyeOff,
  Key,
  Mail,
  ShieldCheck,
  UserCircle2,
  Users,
  MoreHorizontal,
  Layers,
} from "lucide-react";
import { cn } from "@/lib/utils";
import type { Account } from "@/domain/accounts/types";
import { platformLabel } from "@/domain/games/platform";
import type { Platform } from "@/domain/games/types";
import type { AccountSlot } from "@/domain/slots/types";

interface Props {
  account: Account;
  platform: Platform;
  gameTitle: string;
  highlighted?: boolean;
}

export function AccountCard({ account, platform, gameTitle, highlighted }: Props) {
  const [open, setOpen] = useState(highlighted ?? false);
  const [showPass, setShowPass] = useState(false);

  return (
    <div
      className={cn(
        "overflow-hidden rounded-2xl border bg-card shadow-soft transition-all",
        highlighted ? "border-primary ring-2 ring-primary/30 shadow-glow" : "border-border",
      )}
    >
      <button
        onClick={() => setOpen((v) => !v)}
        className="grid w-full grid-cols-[minmax(0,1fr)_auto] items-center gap-4 p-4 text-right hover:bg-accent/40"
      >
        <div className="flex min-w-0 items-center gap-3">
          <div className="grid h-11 w-11 shrink-0 place-items-center rounded-xl gradient-primary text-primary-foreground font-bold text-sm shadow-glow">
            {account.number.slice(-3)}
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-2">
              <span className="truncate text-sm font-semibold">{account.number}</span>
              <StatusBadge status={account.status} />
            </div>
            <div className="mt-0.5 flex items-center gap-2 text-xs text-muted-foreground">
              <span className="truncate">{gameTitle}</span>
              <span className="text-border">•</span>
              <span className="shrink-0 rounded-md bg-muted px-1.5 py-0.5 text-[10px] font-medium">
                {platformLabel(platform)}
              </span>
            </div>
          </div>
        </div>

        <div className="flex shrink-0 items-center gap-2">
          <div className="hidden sm:flex items-center gap-1.5 rounded-lg bg-muted px-2 py-1 text-[11px] text-muted-foreground">
            <Layers className="h-3 w-3" />
            <span className="tabular-nums">{account.slots.length}</span>
            <span>اسلات</span>
          </div>
          <ChevronDown
            className={cn(
              "h-4 w-4 text-muted-foreground transition-transform",
              open && "rotate-180",
            )}
          />
        </div>
      </button>

      <div className="grid grid-cols-1 gap-3 border-t border-border bg-muted/30 p-4 md:grid-cols-2">
        <InfoRow icon={Mail} label="ایمیل" value={account.email} copy />
        <InfoRow
          icon={Key}
          label="رمز عبور"
          value={showPass ? account.password : "•".repeat(account.password.length)}
          copy
          trailing={
            <button
              onClick={() => setShowPass((v) => !v)}
              className="grid h-7 w-7 place-items-center rounded-md text-muted-foreground hover:bg-accent"
              aria-label="toggle password"
            >
              {showPass ? <EyeOff className="h-3.5 w-3.5" /> : <Eye className="h-3.5 w-3.5" />}
            </button>
          }
        />
        <InfoRow icon={UserCircle2} label="Online ID" value={account.onlineId} copy />
        <InfoRow
          icon={ShieldCheck}
          label="کدهای پشتیبان"
          value={account.backupCodes.slice(0, 2).join("  •  ") + "  …"}
        />
      </div>

      {open && (
        <div className="border-t border-border p-4 space-y-3">
          <div className="flex items-center justify-between">
            <h4 className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
              اسلات‌ها
            </h4>
            <span className="text-[11px] text-muted-foreground">
              {account.slots.reduce((n, s) => n + s.customers.length, 0).toLocaleString("fa-IR")} تخصیص
            </span>
          </div>
          <div className="grid gap-3 md:grid-cols-2">
            {account.slots.map((slot) => (
              <SlotBlock key={slot.id} slot={slot} />
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

function StatusBadge({ status }: { status: "active" | "disabled" }) {
  const active = status === "active";
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-medium",
        active
          ? "bg-success/15 text-success"
          : "bg-destructive/15 text-destructive",
      )}
    >
      <span
        className={cn(
          "h-1.5 w-1.5 rounded-full",
          active ? "bg-success animate-pulse" : "bg-destructive",
        )}
      />
      {active ? "فعال" : "غیرفعال"}
    </span>
  );
}

function InfoRow({
  icon: Icon,
  label,
  value,
  copy,
  trailing,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  value: string;
  copy?: boolean;
  trailing?: React.ReactNode;
}) {
  return (
    <div className="grid grid-cols-[auto_minmax(0,1fr)_auto] items-center gap-3 rounded-xl border border-border bg-card px-3 py-2.5">
      <span className="grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-muted text-muted-foreground">
        <Icon className="h-4 w-4" />
      </span>
      <span className="min-w-0">
        <span className="block text-[10px] text-muted-foreground">{label}</span>
        <span className="block truncate font-mono text-xs" dir="ltr">
          {value}
        </span>
      </span>
      <span className="flex shrink-0 items-center gap-1">
        {copy && (
          <button
            onClick={() => navigator.clipboard?.writeText(value)}
            className="grid h-7 w-7 place-items-center rounded-md text-muted-foreground hover:bg-accent"
            aria-label="copy"
          >
            <Copy className="h-3.5 w-3.5" />
          </button>
        )}
        {trailing}
      </span>
    </div>
  );
}

function SlotBlock({ slot }: { slot: AccountSlot }) {
  const isPs5 = slot.type.includes("PS5");
  return (
    <div className="rounded-xl border border-border bg-card p-3">
      <div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-2">
        <div className="min-w-0">
          <div className="flex items-center gap-2">
            <span
              className={cn(
                "shrink-0 rounded-md px-1.5 py-0.5 text-[10px] font-semibold",
                isPs5
                  ? "bg-primary/15 text-primary"
                  : "bg-accent text-accent-foreground",
              )}
            >
              {isPs5 ? "PS5" : "PS4"}
            </span>
            <span className="truncate text-sm font-semibold">{slot.label}</span>
          </div>
          <div className="mt-1 flex items-center gap-1.5 text-[11px] text-muted-foreground">
            <Users className="h-3 w-3" />
            <span className="tabular-nums">{slot.customers.length.toLocaleString("fa-IR")}</span>
            <span>مشتری</span>
          </div>
        </div>
        <button
          className="grid h-7 w-7 shrink-0 place-items-center rounded-md text-muted-foreground hover:bg-accent"
          aria-label="actions"
          title="تخصیص به سفارش · مشاهده مشتریان · کپی اطلاعات"
        >
          <MoreHorizontal className="h-4 w-4" />
        </button>
      </div>

      {slot.customers.length > 0 ? (
        <ul className="mt-3 space-y-1.5">
          {slot.customers.map((c) => (
            <li
              key={c.id}
              className="flex items-center justify-between gap-2 rounded-lg bg-muted/60 px-2.5 py-1.5 text-xs"
            >
              <span className="truncate font-mono" dir="ltr">
                {c.maskedIdentifier}
              </span>
              <span className="shrink-0 text-[10px] text-muted-foreground" dir="ltr">
                {c.orderNumber}
              </span>
            </li>
          ))}
        </ul>
      ) : (
        <div className="mt-3 rounded-lg border border-dashed border-border px-2.5 py-2 text-center text-[11px] text-muted-foreground">
          هنوز مشتری‌ای تخصیص نیافته
        </div>
      )}
    </div>
  );
}
