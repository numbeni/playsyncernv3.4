import type { AccountSlot } from "@/domain/slots/types";

export type AccountStatus = "active" | "disabled";

export interface Account {
  id: string;
  number: string;
  email: string;
  password: string;
  onlineId: string;
  backupCodes: string[];
  status: AccountStatus;
  slots: AccountSlot[];
}
