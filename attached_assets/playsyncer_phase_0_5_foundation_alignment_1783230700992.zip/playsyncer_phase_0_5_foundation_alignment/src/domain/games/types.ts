import type { Account } from "@/domain/accounts/types";

export type Platform = "PS5_ONLY" | "PS4_AND_PS5";

export interface Game {
  id: string;
  title: string;
  cover: string;
  platform: Platform;
  accounts: Account[];
}
