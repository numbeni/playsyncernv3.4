import type { Platform } from "@/domain/games/types";

export const platformLabel = (platform: Platform) =>
  platform === "PS5_ONLY" ? "PS5 Only" : "PS4 + PS5";

export const supportsPs4 = (platform: Platform) => platform === "PS4_AND_PS5";
