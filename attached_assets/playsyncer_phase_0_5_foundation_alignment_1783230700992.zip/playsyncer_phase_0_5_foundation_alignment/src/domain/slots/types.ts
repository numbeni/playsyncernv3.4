export type SlotType = "Z2_PS5_1" | "Z2_PS5_2" | "Z2_PS4_1" | "Z3_PS5";

export interface SlotCustomer {
  id: string;
  maskedIdentifier: string;
  orderNumber: string;
  assignedAt: string;
}

export interface AccountSlot {
  id: string;
  type: SlotType;
  label: string;
  customers: SlotCustomer[];
}
