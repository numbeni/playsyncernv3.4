import { platformLabel } from "@/domain/games/platform";
import type { Game } from "@/domain/games/types";
import type { SearchHit } from "@/domain/search/types";

export const runSmartSearch = (sourceGames: Game[], query: string): SearchHit[] => {
  const q = query.trim().toLowerCase();
  if (!q) return [];

  const hits: SearchHit[] = [];

  for (const game of sourceGames) {
    if (game.title.toLowerCase().includes(q) || game.id.includes(q)) {
      hits.push({
        kind: "game",
        gameId: game.id,
        gameTitle: game.title,
        label: game.title,
        sublabel: platformLabel(game.platform),
      });
    }

    for (const account of game.accounts) {
      if (
        account.email.toLowerCase().includes(q) ||
        account.password.toLowerCase().includes(q) ||
        account.onlineId.toLowerCase().includes(q) ||
        account.number.toLowerCase().includes(q)
      ) {
        hits.push({
          kind: "account",
          gameId: game.id,
          gameTitle: game.title,
          accountId: account.id,
          accountNumber: account.number,
          label: `${account.number} — ${account.email}`,
          sublabel: game.title,
        });
      }

      for (const slot of account.slots) {
        for (const customer of slot.customers) {
          if (
            customer.maskedIdentifier.includes(q) ||
            customer.orderNumber.toLowerCase().includes(q)
          ) {
            hits.push({
              kind: "customer",
              gameId: game.id,
              gameTitle: game.title,
              accountId: account.id,
              accountNumber: account.number,
              label: `${customer.orderNumber} — ${customer.maskedIdentifier}`,
              sublabel: `${game.title} · ${slot.label}`,
            });
          }
        }
      }
    }
  }

  return hits.slice(0, 12);
};
