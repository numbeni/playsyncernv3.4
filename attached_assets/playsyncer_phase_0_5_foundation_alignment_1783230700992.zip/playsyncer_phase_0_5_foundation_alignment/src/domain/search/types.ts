export interface SearchHit {
  kind: "game" | "account" | "customer";
  gameId: string;
  gameTitle: string;
  accountId?: string;
  accountNumber?: string;
  label: string;
  sublabel: string;
}
