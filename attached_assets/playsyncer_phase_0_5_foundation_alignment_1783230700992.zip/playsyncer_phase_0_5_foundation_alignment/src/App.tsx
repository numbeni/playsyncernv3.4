import { Routes, Route, useLocation } from "react-router-dom";
import { ThemeProvider } from "@/hooks/useTheme";
import { SidebarProvider } from "@/hooks/useSidebar";
import { AppSidebar } from "@/components/AppSidebar";
import GamesPage from "@/pages/GamesPage";
import GameDetailPage from "@/pages/GameDetailPage";
import OrdersPage from "@/pages/OrdersPage";
import IssuesPage from "@/pages/IssuesPage";
import StaffPage from "@/pages/StaffPage";
import SettingsPage from "@/pages/SettingsPage";
import NotFoundPage from "@/pages/NotFoundPage";

export default function App() {
  return (
    <ThemeProvider>
      <SidebarProvider>
        <div className="flex min-h-dvh w-full flex-col bg-transparent text-foreground lg:flex-row">
          <AppSidebar />
          <main className="min-w-0 w-full flex-1">
            <AnimatedRoutes />
          </main>
        </div>
      </SidebarProvider>
    </ThemeProvider>
  );
}

function AnimatedRoutes() {
  const location = useLocation();
  return (
    <div key={location.pathname} className="animate-page-in">
      <Routes location={location}>
        <Route path="/" element={<GamesPage />} />
        <Route path="/games/:gameId" element={<GameDetailPage />} />
        <Route path="/orders" element={<OrdersPage />} />
        <Route path="/issues" element={<IssuesPage />} />
        <Route path="/staff" element={<StaffPage />} />
        <Route path="/settings" element={<SettingsPage />} />
        <Route path="*" element={<NotFoundPage />} />
      </Routes>
    </div>
  );
}
