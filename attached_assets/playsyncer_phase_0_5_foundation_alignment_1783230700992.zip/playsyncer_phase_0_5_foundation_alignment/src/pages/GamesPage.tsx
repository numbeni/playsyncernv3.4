import { useEffect, useMemo, useState } from "react";
import { Plus } from "lucide-react";
import { SmartSearch } from "@/components/SmartSearch";
import { GameCard } from "@/components/GameCard";
import { getGameStats } from "@/domain/games/stats";
import { games } from "@/mocks/playSyncerMockData";

export default function GamesPage() {
  const [query, setQuery] = useState("");

  useEffect(() => {
    document.title = "بازی‌ها — PlaySyncer";
  }, []);

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return games;
    return games.filter(
      (g) => g.title.toLowerCase().includes(q) || g.id.toLowerCase().includes(q),
    );
  }, [query]);

  const totals = useMemo(() => {
    return games.reduce(
      (acc, g) => {
        const s = getGameStats(g);
        acc.games += 1;
        acc.accounts += s.totalAccounts;
        acc.slots += s.totalSlots;
        acc.assignments += s.totalAssignments;
        return acc;
      },
      { games: 0, accounts: 0, slots: 0, assignments: 0 },
    );
  }, []);

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-10 lg:py-10">
      <header className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-4">
        <div className="min-w-0">
          <div className="text-xs font-medium text-muted-foreground">داشبورد</div>
          <h1 className="mt-1 truncate text-2xl font-bold tracking-tight sm:text-3xl">
            بازی‌ها
          </h1>
          <p className="mt-1 text-sm text-muted-foreground">
            مدیریت بازی‌ها و اکانت‌های PlayStation
          </p>
        </div>
        <button className="shrink-0 inline-flex items-center gap-2 rounded-xl gradient-primary px-3 py-2 text-sm font-semibold text-primary-foreground shadow-soft transition-shadow hover:shadow-glow sm:px-4">
          <Plus className="h-4 w-4" />
          <span className="hidden sm:inline">افزودن بازی</span>
        </button>
      </header>

      <section className="mt-6 grid grid-cols-2 gap-3 sm:grid-cols-4">
        <OverviewStat label="کل بازی‌ها" value={totals.games} accent="primary" />
        <OverviewStat label="کل اکانت‌ها" value={totals.accounts} />
        <OverviewStat label="کل اسلات‌ها" value={totals.slots} />
        <OverviewStat label="کل تخصیص‌ها" value={totals.assignments} accent="success" />
      </section>

      <section className="mt-6">
        <SmartSearch onGameFilter={setQuery} />
      </section>

      <section className="mt-8">
        {filtered.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-border bg-card p-10 text-center">
            <p className="text-sm text-muted-foreground">
              بازی‌ای با «{query}» پیدا نشد.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
            {filtered.map((g) => (
              <GameCard key={g.id} game={g} />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

function OverviewStat({
  label,
  value,
  accent,
}: {
  label: string;
  value: number;
  accent?: "primary" | "success";
}) {
  return (
    <div className="rounded-2xl border border-border bg-card p-4 shadow-soft">
      <div className="text-[11px] font-medium text-muted-foreground">{label}</div>
      <div
        className={
          "mt-1.5 text-2xl font-bold tabular-nums " +
          (accent === "primary"
            ? "text-primary"
            : accent === "success"
              ? "text-success"
              : "text-foreground")
        }
      >
        {value.toLocaleString("fa-IR")}
      </div>
    </div>
  );
}
