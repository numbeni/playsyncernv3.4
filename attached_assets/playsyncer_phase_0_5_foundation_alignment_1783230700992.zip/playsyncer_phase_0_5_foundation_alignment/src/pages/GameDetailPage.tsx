import { Link, useParams, useSearchParams } from "react-router-dom";
import { useEffect } from "react";
import { ArrowRight, Plus, Gamepad2 } from "lucide-react";
import { AccountCard } from "@/components/AccountCard";
import type { Account } from "@/domain/accounts/types";
import { platformLabel } from "@/domain/games/platform";
import { getGameStats } from "@/domain/games/stats";
import { games } from "@/mocks/playSyncerMockData";
import NotFoundPage from "./NotFoundPage";

export default function GameDetailPage() {
  const { gameId } = useParams();
  const [search] = useSearchParams();
  const highlight = search.get("highlight") ?? undefined;

  const game = games.find((g) => g.id === gameId);

  useEffect(() => {
    document.title = game ? `${game.title} — PlaySyncer` : "بازی — PlaySyncer";
  }, [game]);

  if (!game) return <NotFoundPage />;

  const stats = getGameStats(game);

  return (
    <div className="mx-auto max-w-6xl px-4 py-6 sm:px-6 lg:px-10 lg:py-10">
      <div className="mb-4 flex items-center gap-2 text-xs text-muted-foreground">
        <Link to="/" className="hover:text-foreground">
          بازی‌ها
        </Link>
        <ArrowRight className="h-3 w-3" />
        <span className="text-foreground">{game.title}</span>
      </div>

      <header className="overflow-hidden rounded-2xl border border-border bg-card shadow-elevated">
        <div className="grid grid-cols-1 md:grid-cols-[240px_minmax(0,1fr)]">
          <div className="relative aspect-[16/10] md:aspect-auto md:h-full bg-muted">
            <img
              src={game.cover}
              alt={game.title}
              className="h-full w-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-l from-card via-card/20 to-transparent md:from-card md:via-card/40" />
          </div>

          <div className="p-5 sm:p-6">
            <div className="grid grid-cols-[minmax(0,1fr)_auto] items-start gap-3">
              <div className="min-w-0">
                <span className="inline-flex items-center gap-1 rounded-full bg-primary/15 border border-primary/30 px-2.5 py-1 text-[11px] font-semibold text-primary">
                  <Gamepad2 className="h-3 w-3" />
                  {platformLabel(game.platform)}
                </span>
                <h1 className="mt-2 truncate text-2xl font-bold tracking-tight sm:text-3xl">
                  {game.title}
                </h1>
                <p className="mt-1 text-sm text-muted-foreground">
                  مدیریت اکانت‌ها، اسلات‌ها و تخصیص مشتریان
                </p>
              </div>
              <button className="shrink-0 inline-flex items-center gap-2 rounded-xl gradient-primary px-3 py-2 text-sm font-semibold text-primary-foreground shadow-soft transition-shadow hover:shadow-glow sm:px-4">
                <Plus className="h-4 w-4" />
                <span className="hidden sm:inline">افزودن اکانت</span>
              </button>
            </div>

            <div className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
              <HeaderStat label="کل اکانت‌ها" value={stats.totalAccounts} />
              <HeaderStat label="اکانت‌های فعال" value={stats.activeAccounts} tone="success" />
              <HeaderStat label="کل اسلات‌ها" value={stats.totalSlots} />
              <HeaderStat label="کل تخصیص‌ها" value={stats.totalAssignments} tone="primary" />
            </div>
          </div>
        </div>
      </header>

      <section className="mt-8">
        <div className="mb-4 flex items-center justify-between">
          <h2 className="text-lg font-bold tracking-tight">
            اکانت‌ها
            <span className="mr-2 text-sm font-medium text-muted-foreground">
              ({game.accounts.length.toLocaleString("fa-IR")})
            </span>
          </h2>
        </div>

        <div className="space-y-3">
          {game.accounts.map((acc: Account) => (
            <AccountCard
              key={acc.id}
              account={acc}
              platform={game.platform}
              gameTitle={game.title}
              highlighted={highlight === acc.id}
            />
          ))}
        </div>
      </section>
    </div>
  );
}

function HeaderStat({
  label,
  value,
  tone,
}: {
  label: string;
  value: number;
  tone?: "primary" | "success";
}) {
  return (
    <div className="rounded-xl border border-border bg-muted/40 p-3">
      <div className="text-[11px] text-muted-foreground">{label}</div>
      <div
        className={
          "mt-1 text-xl font-bold tabular-nums " +
          (tone === "primary"
            ? "text-primary"
            : tone === "success"
              ? "text-success"
              : "text-foreground")
        }
      >
        {value.toLocaleString("fa-IR")}
      </div>
    </div>
  );
}
