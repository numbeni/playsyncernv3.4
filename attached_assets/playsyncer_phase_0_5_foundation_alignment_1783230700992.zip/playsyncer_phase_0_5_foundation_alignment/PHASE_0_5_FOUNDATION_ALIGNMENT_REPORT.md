# PlaySyncer — Phase 0.5 Foundation Alignment Report

## هدف فاز

این فاز فقط برای تمیز کردن چهارچوب فعلی انجام شد تا قالب موجود به عنوان پایه رسمی Frontend پروژه قابل ادامه دادن باشد.

## کارهای انجام‌شده

- UI فعلی حفظ شد و بازطراحی نشد.
- `mock-data.ts` از نقش مرکز منطق پروژه خارج شد.
- Typeها به لایه‌های domain منتقل شدند.
- Mock data به مسیر جداگانه منتقل شد.
- نام platform از `PS4_PS5` به `PS4_AND_PS5` اصلاح شد.
- helper آمار بازی‌ها به domain منتقل شد.
- Smart Search از mock-data جدا شد و به domain/search منتقل شد.
- permission scaffold اضافه شد و فعلاً همه دسترسی‌ها `true` برمی‌گردند.

## فایل‌های جدید

```text
src/domain/accounts/types.ts
src/domain/games/types.ts
src/domain/games/platform.ts
src/domain/games/stats.ts
src/domain/permissions/permissions.ts
src/domain/search/types.ts
src/domain/search/smartSearch.ts
src/domain/slots/types.ts
src/mocks/playSyncerMockData.ts
```

## فایل حذف‌شده

```text
src/lib/mock-data.ts
```

## فایل‌های به‌روزشده

```text
src/components/AccountCard.tsx
src/components/GameCard.tsx
src/components/SmartSearch.tsx
src/pages/GameDetailPage.tsx
src/pages/GamesPage.tsx
```

## مواردی که عمداً انجام نشد

- Backend اضافه نشد.
- Auth اضافه نشد.
- WooCommerce integration اضافه نشد.
- Orders Queue واقعی ساخته نشد.
- Permission واقعی enforce نشد.
- UI redesign انجام نشد.
- Add/Edit/Delete واقعی اضافه نشد.

## اعتبارسنجی

```text
npm run build: passed
npm run lint: 0 errors, 2 existing warnings in useTheme/useSidebar fast-refresh rule
```

## گام بعدی

Phase 1 — Games Overview Alignment

در فاز بعدی overview کارت بازی و صفحه داخلی بازی باید از حالت generic به operational stats مخصوص PlaySyncer تبدیل شود.
